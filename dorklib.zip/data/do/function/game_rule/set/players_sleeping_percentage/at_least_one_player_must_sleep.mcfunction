# ⚠️ OVERLAY : overlay-1_21_10

return run gamerule minecraft:players_sleeping_percentage 0
