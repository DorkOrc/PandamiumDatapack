# ⚠️ OVERLAY : overlay-1_21_10

return run gamerule minecraft:players_nether_portal_creative_delay 0
